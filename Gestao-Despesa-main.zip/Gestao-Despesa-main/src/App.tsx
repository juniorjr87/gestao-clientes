/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Login from './components/Login';
import Layout from './components/Layout';
import ExpenseForm from './components/ExpenseForm';
import SupplierManager from './components/SupplierManager';
import CategoryManager from './components/CategoryManager';
import ReportTable from './components/ReportTable';

function AppContent() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('expenses');

  if (!user) {
    return <Login />;
  }

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab}>
      {activeTab === 'expenses' && <ExpenseForm />}
      {activeTab === 'suppliers' && <SupplierManager />}
      {activeTab === 'categories' && <CategoryManager />}
      {activeTab === 'reports' && <ReportTable />}
    </Layout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
