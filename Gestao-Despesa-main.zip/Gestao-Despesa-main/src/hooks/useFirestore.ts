import { useState, useEffect } from 'react';
import { collection, onSnapshot, addDoc, deleteDoc, doc, updateDoc, query, orderBy, where, Timestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Supplier, Expense, Category } from '../types';

export function useCategories() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'categories'), orderBy('name'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Category[];
      setCategories(data);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const addCategory = async (category: Omit<Category, 'id'>) => {
    await addDoc(collection(db, 'categories'), category);
  };

  const updateCategory = async (id: string, data: Partial<Category>) => {
    await updateDoc(doc(db, 'categories', id), data);
  };

  const deleteCategory = async (id: string) => {
    await deleteDoc(doc(db, 'categories', id));
  };

  return { categories, loading, addCategory, updateCategory, deleteCategory };
}

export function useSuppliers() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'suppliers'), orderBy('name'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Supplier[];
      setSuppliers(data);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const addSupplier = async (supplier: Omit<Supplier, 'id'>) => {
    await addDoc(collection(db, 'suppliers'), supplier);
  };

  const updateSupplier = async (id: string, data: Partial<Supplier>) => {
    await updateDoc(doc(db, 'suppliers', id), data);
  };

  const deleteSupplier = async (id: string) => {
    await deleteDoc(doc(db, 'suppliers', id));
  };

  return { suppliers, loading, addSupplier, updateSupplier, deleteSupplier };
}

export function useExpenses(filters: { month?: number, year?: number, date?: string } = {}) {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let q = query(collection(db, 'expenses'), orderBy('date', 'desc'));
    
    // Note: Simple client-side filtering for month/year/date for this demo
    // In production with massive data, use Firestore compound queries with startAt/endAt
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      let data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Expense[];

      if (filters.date) {
        data = data.filter(exp => exp.date === filters.date);
      } else if (filters.month !== undefined && filters.year !== undefined) {
        data = data.filter(exp => {
          const d = new Date(exp.date);
          return d.getMonth() === filters.month && d.getFullYear() === filters.year;
        });
      }

      setExpenses(data);
      setLoading(false);
    });
    return unsubscribe;
  }, [filters.month, filters.year, filters.date]);

  const addExpense = async (expense: Omit<Expense, 'id' | 'createdAt'>) => {
    await addDoc(collection(db, 'expenses'), {
      ...expense,
      createdAt: Timestamp.now()
    });
  };

  const deleteExpense = async (id: string) => {
    await deleteDoc(doc(db, 'expenses', id));
  };

  return { expenses, loading, addExpense, deleteExpense };
}
