import React, { useState } from 'react';
import { useSuppliers, useExpenses } from '../hooks/useFirestore';
import { Plus, Check, FileText } from 'lucide-react';

export default function ExpenseForm() {
  const { suppliers } = useSuppliers();
  const { addExpense } = useExpenses();
  const [supplierId, setSupplierId] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [hasInvoice, setHasInvoice] = useState(true);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supplierId || !amount) return;

    const supplier = suppliers.find(s => s.id === supplierId);
    if (!supplier) return;

    await addExpense({
      supplierId,
      supplierName: supplier.name,
      amount: parseFloat(amount),
      date,
      hasInvoice
    });

    setSuccess(true);
    setTimeout(() => setSuccess(false), 3000);
    setAmount('');
    // Keep date and supplier for rapid entry if needed, or reset? 
    // Usually rapid entry means keeping date, maybe resetting supplier.
    // Let's keep date, reset amount.
  };

  return (
    <div className="max-w-2xl mx-auto bg-white p-8 rounded-xl shadow-lg border border-gray-100">
      <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
        <Plus className="text-indigo-600" />
        Registar Despesa
      </h2>

      {success && (
        <div className="mb-4 p-4 bg-green-50 text-green-700 rounded-md flex items-center gap-2">
          <Check size={20} />
          Despesa registada com sucesso!
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">Fornecedor</label>
            <select
              required
              value={supplierId}
              onChange={(e) => setSupplierId(e.target.value)}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 h-12 text-lg"
            >
              <option value="">Selecione um fornecedor...</option>
              {suppliers.map(s => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Valor (€)</label>
            <input
              type="number"
              step="0.01"
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 h-12 text-lg"
              placeholder="0.00"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Data</label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 h-12 text-lg"
            />
          </div>

          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">Tipo de Documento</label>
            <div className="flex gap-4">
              <button
                type="button"
                onClick={() => setHasInvoice(true)}
                className={`flex-1 py-3 px-4 rounded-lg border flex items-center justify-center gap-2 transition-colors ${
                  hasInvoice
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-md'
                    : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                }`}
              >
                <FileText size={20} />
                Com Fatura
              </button>
              <button
                type="button"
                onClick={() => setHasInvoice(false)}
                className={`flex-1 py-3 px-4 rounded-lg border flex items-center justify-center gap-2 transition-colors ${
                  !hasInvoice
                    ? 'bg-orange-500 text-white border-orange-500 shadow-md'
                    : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                }`}
              >
                <span className="font-bold text-lg">S/F</span>
                Sem Fatura
              </button>
            </div>
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-indigo-600 text-white py-4 px-6 rounded-lg font-bold text-lg hover:bg-indigo-700 shadow-lg transform transition hover:-translate-y-0.5"
        >
          Registar Despesa
        </button>
      </form>
    </div>
  );
}
