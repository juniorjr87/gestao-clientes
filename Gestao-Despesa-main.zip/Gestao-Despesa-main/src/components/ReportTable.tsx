import React, { useState, useMemo } from 'react';
import { useSuppliers, useExpenses } from '../hooks/useFirestore';
import { formatCurrency } from '../lib/utils';
import { Download, FileSpreadsheet, FileText } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import logoImg from '../logo.png';

export default function ReportTable() {
  const [reportType, setReportType] = useState<'monthly' | 'daily'>('monthly');
  const [month, setMonth] = useState(new Date().getMonth());
  const [year, setYear] = useState(new Date().getFullYear());
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  
  const { suppliers } = useSuppliers();
  const { expenses, loading } = useExpenses(
    reportType === 'monthly' 
      ? { month, year } 
      : { date }
  );

  const reportData = useMemo(() => {
    const data: Record<string, {
      supplierName: string;
      category: string;
      color: string;
      invoiceTotal: number;
      noInvoiceTotal: number;
      total: number;
    }> = {};

    // Initialize with all suppliers to show even those with 0 expenses?
    // Requirement says "Report Monthly", usually only active suppliers.
    // But let's iterate expenses first.
    
    expenses.forEach(exp => {
      if (!data[exp.supplierId]) {
        const supplier = suppliers.find(s => s.id === exp.supplierId);
        data[exp.supplierId] = {
          supplierName: supplier?.name || exp.supplierName || 'Desconhecido',
          category: supplier?.category || 'Outros',
          color: supplier?.color || 'bg-white',
          invoiceTotal: 0,
          noInvoiceTotal: 0,
          total: 0
        };
      }
      
      if (exp.hasInvoice) {
        data[exp.supplierId].invoiceTotal += exp.amount;
      } else {
        data[exp.supplierId].noInvoiceTotal += exp.amount;
      }
      data[exp.supplierId].total += exp.amount;
    });

    return Object.values(data).sort((a, b) => b.total - a.total);
  }, [expenses, suppliers]);

  const totals = useMemo(() => {
    return reportData.reduce((acc, curr) => ({
      invoice: acc.invoice + curr.invoiceTotal,
      noInvoice: acc.noInvoice + curr.noInvoiceTotal,
      total: acc.total + curr.total
    }), { invoice: 0, noInvoice: 0, total: 0 });
  }, [reportData]);

  const exportPDF = async () => {
    const doc = new jsPDF();
    
    // Add Logo
    try {
      const imgData = await new Promise<string>((resolve, reject) => {
        const img = new Image();
        img.src = logoImg;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.width = img.width;
          canvas.height = img.height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0);
          resolve(canvas.toDataURL('image/png'));
        };
        img.onerror = reject;
      });
      doc.addImage(imgData, 'PNG', 14, 10, 50, 0); // x, y, w, h (0 = auto height)
    } catch (e) {
      console.error("Could not load logo for PDF", e);
    }

    const title = reportType === 'monthly' 
      ? `Relatório de Despesas - ${month + 1}/${year}`
      : `Relatório de Despesas - ${date}`;
    
    doc.setFontSize(16);
    doc.text("Restaurante O Junior", 75, 18);
    doc.setFontSize(12);
    doc.text(title, 75, 26);
    
    const tableColumn = ["Fornecedor", "Com Fatura", "S/Fatura", "Total"];
    const tableRows = [];

    reportData.forEach(row => {
      const rowData = [
        row.supplierName,
        formatCurrency(row.invoiceTotal),
        formatCurrency(row.noInvoiceTotal),
        formatCurrency(row.total)
      ];
      tableRows.push(rowData);
    });

    // Add Totals Row
    tableRows.push([
      "TOTAIS",
      formatCurrency(totals.invoice),
      formatCurrency(totals.noInvoice),
      formatCurrency(totals.total)
    ]);

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 50,
      theme: 'grid',
      styles: { fontSize: 10 },
      headStyles: { fillColor: [63, 81, 181] },
      footStyles: { fillColor: [22, 163, 74], textColor: [255, 255, 255], fontStyle: 'bold' },
      didParseCell: (data) => {
        // Apply background color to body rows based on category
        if (data.section === 'body' && data.row.index < reportData.length) {
          const row = reportData[data.row.index];
          // Simple mapping for the default categories
          if (row.color.includes('blue')) data.cell.styles.fillColor = [219, 234, 254];
          else if (row.color.includes('orange')) data.cell.styles.fillColor = [255, 237, 213];
          else if (row.color.includes('purple')) data.cell.styles.fillColor = [243, 232, 255];
          else if (row.color.includes('green')) data.cell.styles.fillColor = [220, 252, 231];
          else if (row.color.includes('gray')) data.cell.styles.fillColor = [243, 244, 246];
        }
      }
    });

    const filename = reportType === 'monthly' 
      ? `relatorio_despesas_${month + 1}_${year}.pdf`
      : `relatorio_despesas_${date}.pdf`;
    doc.save(filename);
  };

  const exportExcel = () => {
    const ws = XLSX.utils.json_to_sheet(reportData.map(row => ({
      Fornecedor: row.supplierName,
      Categoria: row.category,
      "Com Fatura": row.invoiceTotal,
      "Sem Fatura": row.noInvoiceTotal,
      "Total": row.total
    })));

    // Add totals row manually
    XLSX.utils.sheet_add_json(ws, [{
      Fornecedor: "TOTAIS",
      Categoria: "",
      "Com Fatura": totals.invoice,
      "Sem Fatura": totals.noInvoice,
      "Total": totals.total
    }], { skipHeader: true, origin: -1 });

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Despesas");
    
    const filename = reportType === 'monthly' 
      ? `relatorio_despesas_${month + 1}_${year}.xlsx`
      : `relatorio_despesas_${date}.xlsx`;
    XLSX.writeFile(wb, filename);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 bg-white p-4 rounded-lg shadow-sm border border-gray-200">
        <div className="flex items-center gap-4 border-b border-gray-100 pb-4">
          <label className="inline-flex items-center">
            <input
              type="radio"
              className="form-radio text-indigo-600"
              name="reportType"
              value="monthly"
              checked={reportType === 'monthly'}
              onChange={() => setReportType('monthly')}
            />
            <span className="ml-2">Relatório Mensal</span>
          </label>
          <label className="inline-flex items-center">
            <input
              type="radio"
              className="form-radio text-indigo-600"
              name="reportType"
              value="daily"
              checked={reportType === 'daily'}
              onChange={() => setReportType('daily')}
            />
            <span className="ml-2">Relatório Diário</span>
          </label>
        </div>

        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-4 w-full sm:w-auto">
            {reportType === 'monthly' ? (
              <>
                <select
                  value={month}
                  onChange={(e) => setMonth(parseInt(e.target.value))}
                  className="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-2 pl-3 pr-10 text-base"
                >
                  {Array.from({ length: 12 }, (_, i) => (
                    <option key={i} value={i}>{new Date(0, i).toLocaleString('pt-PT', { month: 'long' })}</option>
                  ))}
                </select>
                <select
                  value={year}
                  onChange={(e) => setYear(parseInt(e.target.value))}
                  className="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-2 pl-3 pr-10 text-base"
                >
                  {[2023, 2024, 2025, 2026, 2027].map(y => (
                    <option key={y} value={y}>{y}</option>
                  ))}
                </select>
              </>
            ) : (
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-2 px-3 text-base w-full sm:w-auto"
              />
            )}
          </div>
          
          <div className="flex gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={exportPDF}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
            >
              <FileText className="mr-2 h-4 w-4" />
              PDF
            </button>
            <button
              onClick={exportExcel}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              <FileSpreadsheet className="mr-2 h-4 w-4" />
              Excel
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider">Total Com Fatura</h3>
          <p className="mt-2 text-3xl font-bold text-indigo-600">{formatCurrency(totals.invoice)}</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider">Total S/ Fatura</h3>
          <p className="mt-2 text-3xl font-bold text-orange-600">{formatCurrency(totals.noInvoice)}</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider">Total Global</h3>
          <p className="mt-2 text-3xl font-bold text-green-600">{formatCurrency(totals.total)}</p>
        </div>
      </div>

      <div className="bg-white shadow overflow-hidden rounded-lg border border-gray-200">
        {loading ? (
          <div className="p-12 text-center text-gray-500">A carregar dados...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Fornecedores
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Com Fatura
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    S/Fatura
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider font-bold">
                    Total
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {reportData.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-6 py-12 text-center text-gray-500">
                      Sem registos para este período.
                    </td>
                  </tr>
                ) : (
                  reportData.map((row, idx) => (
                    <tr key={idx} className={`${row.color} bg-opacity-30 hover:bg-opacity-50 transition-colors`}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {row.supplierName}
                        <span className="ml-2 text-xs text-gray-500 font-normal">({row.category})</span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-700">
                        {formatCurrency(row.invoiceTotal)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-700">
                        {formatCurrency(row.noInvoiceTotal)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-right font-bold text-gray-900">
                        {formatCurrency(row.total)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
              <tfoot className="bg-green-600 font-bold border-t-2 border-green-700">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-base text-white">
                    TOTAIS
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-base text-right text-white">
                    {formatCurrency(totals.invoice)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-base text-right text-white">
                    {formatCurrency(totals.noInvoice)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-lg text-right text-white border-t-2 border-green-400">
                    {formatCurrency(totals.total)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
