import React, { useState, useEffect } from 'react';
import { useSuppliers, useCategories } from '../hooks/useFirestore';
import { DEFAULT_CATEGORIES } from '../types';
import { Plus, Trash2, Edit2, X, Save } from 'lucide-react';

export default function SupplierManager() {
  const { suppliers, addSupplier, deleteSupplier, updateSupplier } = useSuppliers();
  const { categories } = useCategories();
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // Form State
  const [name, setName] = useState('');
  const [category, setCategory] = useState('');
  const [color, setColor] = useState('');

  // Set initial state when categories load or when adding new
  useEffect(() => {
    if (categories.length > 0 && !category) {
      setCategory(categories[0].name);
      setColor(categories[0].color);
    } else if (categories.length === 0 && !category) {
      // Fallback if no categories exist yet
      setCategory(DEFAULT_CATEGORIES[0].name);
      setColor(DEFAULT_CATEGORIES[0].color);
    }
  }, [categories, category]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      await updateSupplier(editingId, { name, category, color });
      setEditingId(null);
    } else {
      await addSupplier({ name, category, color });
    }
    resetForm();
  };

  const resetForm = () => {
    setName('');
    if (categories.length > 0) {
      setCategory(categories[0].name);
      setColor(categories[0].color);
    } else {
      setCategory(DEFAULT_CATEGORIES[0].name);
      setColor(DEFAULT_CATEGORIES[0].color);
    }
    setIsAdding(false);
    setEditingId(null);
  };

  const handleEdit = (supplier: any) => {
    setName(supplier.name);
    setCategory(supplier.category);
    setColor(supplier.color);
    setEditingId(supplier.id);
    setIsAdding(true);
  };

  const activeCategories = categories.length > 0 ? categories : DEFAULT_CATEGORIES;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Gestão de Fornecedores</h2>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-md flex items-center gap-2 hover:bg-indigo-700"
        >
          {isAdding ? <X size={20} /> : <Plus size={20} />}
          {isAdding ? 'Cancelar' : 'Novo Fornecedor'}
        </button>
      </div>

      {isAdding && (
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Nome</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 border p-2"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Categoria</label>
                <select
                  value={category}
                  onChange={(e) => {
                    const cat = activeCategories.find(c => c.name === e.target.value);
                    setCategory(e.target.value);
                    if (cat) setColor(cat.color);
                  }}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 border p-2"
                >
                  {activeCategories.map(c => (
                    <option key={c.name} value={c.name}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Cor (Pré-visualização)</label>
                <div className={`mt-1 h-10 w-full rounded-md border border-gray-200 ${color} flex items-center justify-center text-sm font-medium text-gray-700`}>
                  Exemplo de Linha
                </div>
              </div>
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                className="bg-green-600 text-white px-4 py-2 rounded-md flex items-center gap-2 hover:bg-green-700"
              >
                <Save size={20} />
                Guardar
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {suppliers.map((supplier) => (
            <li key={supplier.id} className={`px-6 py-4 flex items-center justify-between hover:bg-gray-50 ${supplier.color} bg-opacity-20`}>
              <div>
                <p className="text-sm font-medium text-gray-900">{supplier.name}</p>
                <p className="text-sm text-gray-500">{supplier.category}</p>
              </div>
              <div className="flex space-x-3">
                <button
                  onClick={() => handleEdit(supplier)}
                  className="text-indigo-600 hover:text-indigo-900"
                >
                  <Edit2 size={18} />
                </button>
                <button
                  onClick={() => {
                    if (window.confirm('Tem a certeza?')) deleteSupplier(supplier.id);
                  }}
                  className="text-red-600 hover:text-red-900"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </li>
          ))}
          {suppliers.length === 0 && (
            <li className="px-6 py-12 text-center text-gray-500">
              Nenhum fornecedor registado.
            </li>
          )}
        </ul>
      </div>
    </div>
  );
}
