import React, { useState } from 'react';
import { useCategories } from '../hooks/useFirestore';
import { Plus, Trash2, Edit2, X, Save } from 'lucide-react';

const PRESET_COLORS = [
  { name: 'Azul', value: 'bg-blue-100' },
  { name: 'Laranja', value: 'bg-orange-100' },
  { name: 'Roxo', value: 'bg-purple-100' },
  { name: 'Verde', value: 'bg-green-100' },
  { name: 'Cinza', value: 'bg-gray-100' },
  { name: 'Vermelho', value: 'bg-red-100' },
  { name: 'Amarelo', value: 'bg-yellow-100' },
  { name: 'Rosa', value: 'bg-pink-100' },
  { name: 'Indigo', value: 'bg-indigo-100' },
  { name: 'Teal', value: 'bg-teal-100' },
];

export default function CategoryManager() {
  const { categories, addCategory, deleteCategory, updateCategory } = useCategories();
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // Form State
  const [name, setName] = useState('');
  const [color, setColor] = useState(PRESET_COLORS[0].value);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      await updateCategory(editingId, { name, color });
      setEditingId(null);
    } else {
      await addCategory({ name, color });
    }
    resetForm();
  };

  const resetForm = () => {
    setName('');
    setColor(PRESET_COLORS[0].value);
    setIsAdding(false);
    setEditingId(null);
  };

  const handleEdit = (category: any) => {
    setName(category.name);
    setColor(category.color);
    setEditingId(category.id);
    setIsAdding(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Gestão de Categorias</h2>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-md flex items-center gap-2 hover:bg-indigo-700"
        >
          {isAdding ? <X size={20} /> : <Plus size={20} />}
          {isAdding ? 'Cancelar' : 'Nova Categoria'}
        </button>
      </div>

      {isAdding && (
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Nome da Categoria</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 border p-2"
                  placeholder="Ex: Renda, Bebidas..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Cor de Fundo</label>
                <div className="mt-1 grid grid-cols-5 gap-2">
                  {PRESET_COLORS.map((c) => (
                    <button
                      key={c.value}
                      type="button"
                      onClick={() => setColor(c.value)}
                      className={`h-8 w-full rounded border ${c.value} ${
                        color === c.value ? 'ring-2 ring-indigo-500 ring-offset-2 border-indigo-500' : 'border-gray-200'
                      }`}
                      title={c.name}
                    />
                  ))}
                </div>
              </div>
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                className="bg-green-600 text-white px-4 py-2 rounded-md flex items-center gap-2 hover:bg-green-700"
              >
                <Save size={20} />
                Guardar
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {categories.map((cat) => (
            <li key={cat.id} className={`px-6 py-4 flex items-center justify-between hover:bg-gray-50 ${cat.color} bg-opacity-20`}>
              <div className="flex items-center gap-3">
                <div className={`w-6 h-6 rounded border border-gray-300 ${cat.color}`}></div>
                <p className="text-sm font-medium text-gray-900">{cat.name}</p>
              </div>
              <div className="flex space-x-3">
                <button
                  onClick={() => handleEdit(cat)}
                  className="text-indigo-600 hover:text-indigo-900"
                >
                  <Edit2 size={18} />
                </button>
                <button
                  onClick={() => {
                    if (window.confirm('Tem a certeza? Isto não apaga os fornecedores associados, mas pode afetar a consistência.')) deleteCategory(cat.id);
                  }}
                  className="text-red-600 hover:text-red-900"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </li>
          ))}
          {categories.length === 0 && (
            <li className="px-6 py-12 text-center text-gray-500">
              Nenhuma categoria registada. Adicione uma nova categoria para começar.
            </li>
          )}
        </ul>
      </div>
    </div>
  );
}
