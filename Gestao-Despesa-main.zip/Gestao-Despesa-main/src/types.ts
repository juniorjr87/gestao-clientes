export interface Supplier {
  id: string;
  name: string;
  category: string;
  color: string; // Hex code or Tailwind class
}

export interface Category {
  id: string;
  name: string;
  color: string;
}

export interface Expense {
  id: string;
  supplierId: string;
  supplierName: string; // Denormalized for easier display/export
  amount: number;
  date: string; // YYYY-MM-DD
  hasInvoice: boolean;
  createdAt: any; // Firestore Timestamp
}

// Fallback/Default categories for initial setup if needed, but primarily we use Firestore now.
export const DEFAULT_CATEGORIES = [
  { name: 'Custos Fixos', color: 'bg-blue-100' },
  { name: 'Alimentação', color: 'bg-orange-100' },
  { name: 'Bebidas', color: 'bg-purple-100' },
  { name: 'Limpeza', color: 'bg-green-100' },
  { name: 'Outros', color: 'bg-gray-100' },
];
